import "../App.css";
import ToDoButton from "./ToDoButton";

export default function Main({list, addList, updateList, deleteList}) {
  return  (
    <div className="App">
      <div className="buttonBox">
        <button className="plusButton" onClick={addList}>
          Plus
        </button>
        <button className="plusButton">
          Storage
        </button>
      </div>
      {list.map((item) => {
        return (<ToDoButton 
          key={item.id}
          item={item}
          updateContent={updateList}
          deleteList={()=>deleteList(item.id)}
        />)
      })}
    </div>
  )
}

// import React from "react";
// import { Link } from "react-router-dom";
// import "../App.css";
// import ToDoButton from "./ToDoButton";

// export default function Main({ list, addList, updateList, deleteList }) {
//   const handleStorageClick = () => {
//     localStorage.setItem("storedText", inputText);
//   };

//   return (
//     <div className="App">
//       <div className="buttonBox">
//         <button className="plusButton" onClick={addList}>
//           Plus
//         </button>
//         <Link to="/storage">
//           <button className="plusButton" onClick={handleStorageClick}>
//             Storage
//           </button>
//         </Link>
//       </div>
//       {list.map((item) => {
//         return (
//           <ToDoButton
//             key={item.id}
//             item={item}
//             updateContent={updateList}
//             deleteList={() => deleteList(item.id)}
//           />
//         );
//       })}
//     </div>
//   );
// }
