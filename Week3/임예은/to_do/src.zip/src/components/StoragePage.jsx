// // StoragePage.js
// import React, { useState, useEffect } from "react";


// const StoragePage = () => {
//   const [storedText, setStoredText] = useState("");

//   useEffect(() => {
//     const text = localStorage.getItem("storedText");
//     if (text) {
//       setStoredText(text);
//     }
//   }, []);

//   return (
//     <div>
//       <h2>Stored Text</h2>
//       <p>{storedText}</p>
//     </div>
//   );
// };

// export default StoragePage;

// // StoragePage.js
// import React, { useState, useEffect } from "react";


// const StoragePage = () => {
//   const [storedText, setStoredText] = useState("");

//   useEffect(() => {
//     const text = localStorage.getItem("storedText");
//     if (text) {
//       setStoredText(text);
//     }
//   }, []);

//   return (
//     <div>
//       <p>{storedText}</p>
//     </div>
//   );
// };

// export default StoragePage;

import React, { useState, useEffect } from "react";

const StoragePage = () => {
  const [storedText, setStoredText] = useState(""); // 초기값을 빈 문자열로 설정

  useEffect(() => {
    const text = localStorage.getItem("storedText");
    if (text !== null) { // 값이 null이 아닌 경우에만 상태를 업데이트합니다.
      setStoredText(text);
    }
  }, []);

  return (
    <div>
      <p>{storedText}</p>
    </div>
  );
};

export default StoragePage;
