// // Memo.js

// import React from "react";

// function Memo({ addMemo, memos, deleteMemo }) {
//   // 메모 UI 및 기능을 여기에 구현합니다.
//   return (
//     <div>
//       {/* 메모 UI */}
//     </div>
//   );
// }

// export default Memo;
// /