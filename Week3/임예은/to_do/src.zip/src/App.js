// App.js
import React, { useState } from "react";
import { Routes, Route, Link } from "react-router-dom";
import Main from "./components/Main";
import StoragePage from "./components/StoragePage";

function App() {
  const [list, setList] = useState([]);

  function addList() {
    const newItem = {
      id: Date.now(),
      content: "",
    };
    setList((prevList) => [...prevList, newItem]);
  }

  function updateList(itemId, newContent) {
    setList((prevList) =>
      prevList.map((item) =>
        item.id === itemId ? { ...item, content: newContent } : item
      )
    );
  }

  function deleteList(itemId) {
    setList((prevList) => prevList.filter((item) => item.id !== itemId));
  }

  return (
    <div>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/storage">Storage</Link>
          </li>
        </ul>
      </nav>

      <Routes>
        <Route
          path="/"
          element={
            <Main
              list={list}
              addList={addList}
              updateList={updateList}
              deleteList={deleteList}
            />
          }
        />
        <Route path="/storage" element={<StoragePage />} />
      </Routes>
    </div>
  );
}

export default App;

