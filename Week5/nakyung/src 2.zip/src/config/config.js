const Config = {
  baseURL: 'http://52.78.139.114:8081',
  headers: {
    'Content-Type': 'application/json',
  },
};

export default Config;
